"""
Performance metrics — §3.8

Six metrics are computed for each governance model × scenario × run:

  Congestion (§3.8.1):
    1. AVWT  — Average Vehicle Waiting Time (seconds)
    2. Throughput — total vehicles completing their journey

  Transparency (§3.8.2):
    3. ES — Explainability Score (0–1; higher = more interpretable)

  Fairness (§3.8.3):
    4. JFI — Jain's Fairness Index (0–1; higher = more equitable)

Additional helpers:
    • per_run_record()   — pack a single run's metrics into a flat dict
    • fairness_index()   — Jain's formula
    • explainability_score() — model-appropriate ES dispatcher
"""

from __future__ import annotations

import math
from typing import Dict, List, Optional

import numpy as np


# ─── Congestion ───────────────────────────────────────────────────────────────
def average_vehicle_waiting_time(results: dict) -> float:
    """
    AVWT = mean waiting time across all vehicles that were active during the
    simulation (seconds).  Includes vehicles not yet completed.
    Per §3.8.1.
    """
    return float(results.get("avwt", 0.0))


def network_throughput(results: dict) -> int:
    """Total vehicles completing their trip during the simulation. §3.8.1."""
    return int(results.get("throughput", 0))


# ─── Fairness — Jain's Index ──────────────────────────────────────────────────
def fairness_index(per_lane_wait: List[float]) -> float:
    """
    Jain's Fairness Index (Jain et al., 1984).

        JFI = (Σ x_i)²  / (n × Σ x_i²)

    where x_i = average waiting time for lane i.

    Range: [1/n, 1].   Value of 1 ⇒ all lanes have identical service.
    Per §3.8.3.
    """
    arr = np.array(per_lane_wait, dtype=np.float64)
    if len(arr) == 0 or np.all(arr == 0):
        return 1.0   # trivially fair (no demand)
    n = len(arr)
    return float((arr.sum() ** 2) / (n * (arr ** 2).sum()))


# ─── Explainability Score ─────────────────────────────────────────────────────
def explainability_score(governance_model: str, controller, results: dict) -> float:
    """
    Compute ES according to §3.8.2 rules:

      deterministic → 1.0  (fully transparent timing plan)
      human         → fraction of identifiable decisions (from decision log)
      ai            → mean normalised SHAP top-3 score
      hybrid        → weighted average of component ESs
    """
    g = governance_model.lower()
    if g == "deterministic":
        return 1.0

    if hasattr(controller, "explainability_score"):
        return controller.explainability_score()

    return 0.0   # fallback


# ─── Per-run record ───────────────────────────────────────────────────────────
def per_run_record(
    governance_model: str,
    scenario_key: str,
    run_idx: int,
    results: dict,
    controller,
) -> dict:
    """
    Assemble all six metrics into a flat dictionary suitable for a DataFrame row.
    """
    avwt = average_vehicle_waiting_time(results)
    tp = network_throughput(results)
    jfi = fairness_index(results.get("per_lane_wait", []))
    es = explainability_score(governance_model, controller, results)

    return {
        "governance": governance_model,
        "scenario": scenario_key,
        "run": run_idx,
        "avwt": avwt,
        "throughput": tp,
        "jain_fairness_index": jfi,
        "explainability_score": es,
    }
