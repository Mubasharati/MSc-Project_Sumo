"""
SUMO TraCI environment wrapper.

Used when SUMO is installed (apt install sumo).  Provides the same
interface as GridSimulation so the governance models and runners are
backend-agnostic.

Usage:
    from simulation.sumo_env import SumoEnv
    env = SumoEnv(scenario_key="peak", seed=42, controller=my_ctrl)
    results = env.run_full()
"""

from __future__ import annotations

import os
import sys
import subprocess
import random
from typing import Optional, Dict

import numpy as np

from config import (
    SUMO_BINARY, SUMO_CFG_PATH, SUMO_STEP_LENGTH, SIMULATION_DURATION,
    GRID_ROWS, GRID_COLS,
)

_SUMO_AVAILABLE = False
try:
    import traci
    _SUMO_AVAILABLE = True
except ImportError:
    pass


def sumo_available() -> bool:
    if not _SUMO_AVAILABLE:
        return False
    result = subprocess.run(
        ["which", SUMO_BINARY], capture_output=True
    )
    return result.returncode == 0


class SumoEnv:
    """
    Wraps SUMO via TraCI.  Falls back to pure-Python GridSimulation if
    SUMO is not available.
    """

    def __init__(
        self,
        scenario_key: str,
        seed: int = 42,
        controller=None,
        duration: int = SIMULATION_DURATION,
        gui: bool = False,
    ):
        self.scenario_key = scenario_key
        self.seed = seed
        self.controller = controller
        self.duration = duration
        self.gui = gui
        self.t = 0

        if sumo_available():
            self._backend = "sumo"
            self._prepare_scenario()
        else:
            self._backend = "python"
            from simulation.grid_sim import GridSimulation
            self._sim = GridSimulation(
                scenario_key=scenario_key,
                seed=seed,
                controller=controller,
                duration=duration,
            )

    # ─── SUMO route file generation ───────────────────────────────────────────
    def _prepare_scenario(self):
        """Write the routes file for the selected scenario to disk."""
        from config import SCENARIOS, SATURATION_FLOW_PS
        import xml.etree.ElementTree as ET

        scen = SCENARIOS[self.scenario_key]
        demand_factor = scen["demand_factor"]
        cap = SATURATION_FLOW_PS * 2 * (GRID_ROWS + GRID_COLS) * 2
        rate = demand_factor * cap  # vehicles/second (network-wide)

        root = ET.Element("routes")

        # Vehicle type
        ET.SubElement(root, "vType", {
            "id": "car",
            "accel": "2.6",
            "decel": "4.5",
            "length": "5",
            "maxSpeed": "13.89",
            "sigma": "0.5",
        })

        # One flow per perimeter entry, entering with Poisson rate
        num_entries = 2 * (GRID_ROWS + GRID_COLS)
        rate_per_entry = rate / num_entries
        period = max(1, int(1 / rate_per_entry)) if rate_per_entry > 0 else 9999

        flow_id = 0
        for c in range(GRID_COLS):
            for suffix, edge_in in [("N", f"src_N_{c}_in"), ("S", f"src_S_{c}_in")]:
                ET.SubElement(root, "flow", {
                    "id": str(flow_id),
                    "type": "car",
                    "from": edge_in.replace("_in", ""),
                    "to": f"src_S_{random.randint(0, GRID_COLS - 1)}",
                    "begin": "0",
                    "end": str(self.duration),
                    "period": str(period),
                    "departLane": "random",
                    "departSpeed": "max",
                })
                flow_id += 1

        route_path = os.path.join(
            os.path.dirname(SUMO_CFG_PATH),
            "scenarios", "current.rou.xml",
        )
        os.makedirs(os.path.dirname(route_path), exist_ok=True)
        tree = ET.ElementTree(root)
        tree.write(route_path, xml_declaration=True, encoding="unicode")

    # ─── TraCI run ────────────────────────────────────────────────────────────
    def run_full(self) -> dict:
        if self._backend == "python":
            return self._sim.run_full()

        import traci
        binary = SUMO_BINARY if not self.gui else "sumo-gui"
        traci.start([binary, "-c", SUMO_CFG_PATH, "--seed", str(self.seed)])

        tl_ids = traci.trafficlight.getIDList()
        obs = self._get_obs_sumo(tl_ids)
        step_log = []
        completed = 0

        for t in range(self.duration):
            if self.controller:
                phase_cmds = self.controller.act(obs, self)
                for tl_id, phase in phase_cmds.items():
                    if tl_id in tl_ids:
                        traci.trafficlight.setPhase(tl_id, phase)
            traci.simulationStep()
            completed += traci.simulation.getArrivedNumber()
            step_log.append({"t": t, "completed": completed})
            obs = self._get_obs_sumo(tl_ids)

        # Collect tripinfo
        wait_times = []
        for vid in traci.vehicle.getIDList():
            wait_times.append(traci.vehicle.getWaitingTime(vid))

        traci.close()

        avwt = float(np.mean(wait_times)) if wait_times else 0.0
        return {
            "avwt": avwt,
            "throughput": completed,
            "per_lane_wait": wait_times,
            "step_log": step_log,
            "intersection_obs": {},
            "duration": self.duration,
        }

    def _get_obs_sumo(self, tl_ids) -> dict:
        """Build per-TL observation from SUMO detector data."""
        import traci
        obs = {}
        for tl_id in tl_ids:
            lanes = traci.trafficlight.getControlledLanes(tl_id)
            q = [traci.lane.getLastStepHaltingNumber(ln) for ln in lanes[:4]]
            while len(q) < 4:
                q.append(0)
            phase = traci.trafficlight.getPhase(tl_id)
            obs[tl_id] = np.array(q[:4] + [phase, 0.0], dtype=np.float32)
        return obs
