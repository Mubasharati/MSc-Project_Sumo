"""
Pure-Python 4×4 urban grid traffic simulation.

Models the SUMO-based experiment described in Chapter 3 of the dissertation
without requiring a SUMO installation.  Implements:
  • Discrete-time (1 s step) microscopic queue model
  • 16 intersections arranged in a 4×4 grid
  • Four-phase signal control at every intersection
  • Vehicle generation via demand-rate Poisson process
  • Full metric collection: AVWT, throughput, queue lengths (for SHAP)

The SUMO TraCI variant (simulation/sumo_env.py) wraps this same interface
but delegates to SUMO when installed.
"""

from __future__ import annotations

import random
import math
from collections import defaultdict
from typing import Dict, List, Optional, Tuple

import numpy as np

from config import (
    GRID_ROWS, GRID_COLS, SATURATION_FLOW_PS, YELLOW_DURATION,
    MIN_GREEN, SIMULATION_DURATION, LOST_TIME_PER_PHASE,
    SCENARIOS, HEADWAY_S,
)


# ─── Constants ────────────────────────────────────────────────────────────────
PHASE_NS_GREEN  = 0   # North-South green,  East-West red
PHASE_NS_YELLOW = 1   # all-yellow / clearance
PHASE_EW_GREEN  = 2   # East-West green,    North-South red
PHASE_EW_YELLOW = 3   # all-yellow / clearance

GREEN_PHASES = {PHASE_NS_GREEN, PHASE_EW_GREEN}
NS_APPROACHES = ("N", "S")   # approaches that move on NS green
EW_APPROACHES = ("E", "W")   # approaches that move on EW green

# Travel time for one grid step at 50 km/h (200 m)
TRAVEL_TIME_S = 200 / 13.89  # ≈ 14.4 s


# ─── Data Classes ─────────────────────────────────────────────────────────────
class Vehicle:
    """A single simulated vehicle."""
    _id_counter = 0

    def __init__(self, origin: str, route: List[Tuple[int, int, str]]):
        Vehicle._id_counter += 1
        self.vid = Vehicle._id_counter
        self.origin = origin
        # route: list of (row, col, approach_direction) intersection visits
        self.route = route
        self.route_idx = 0
        self.spawn_time: int = 0
        self.wait_time: float = 0.0         # total seconds waiting at red
        self.completed = False
        self.in_transit: Optional[float] = None   # arrives at intersection at this t


class IntersectionState:
    """Per-intersection mutable state."""

    def __init__(self, row: int, col: int):
        self.row = row
        self.col = col
        self.phase: int = PHASE_NS_GREEN
        self.phase_timer: float = 0.0          # seconds in current phase
        # per-approach queues: "N","S","E","W"
        self.queues: Dict[str, List[Vehicle]] = {"N": [], "S": [], "E": [], "W": []}
        # vehicles currently in transit toward this intersection
        self.in_transit: Dict[str, List[Tuple[float, Vehicle]]] = {
            "N": [], "S": [], "E": [], "W": []
        }
        # cumulative wait recorded each step
        self.cumulative_wait: float = 0.0
        self.decisions: List[dict] = []        # decision log for explainability

    @property
    def node_id(self) -> str:
        return f"n_{self.row}_{self.col}"

    def queue_lengths(self) -> Dict[str, int]:
        return {d: len(q) for d, q in self.queues.items()}

    def total_queue(self) -> int:
        return sum(len(q) for q in self.queues.values())

    def ns_queue(self) -> int:
        return len(self.queues["N"]) + len(self.queues["S"])

    def ew_queue(self) -> int:
        return len(self.queues["E"]) + len(self.queues["W"])

    def get_obs(self) -> np.ndarray:
        """Observation vector for RL: [q_N, q_S, q_E, q_W, phase, phase_timer/60]."""
        ql = self.queue_lengths()
        return np.array([
            ql["N"], ql["S"], ql["E"], ql["W"],
            self.phase,
            min(self.phase_timer / 60.0, 1.0),
        ], dtype=np.float32)


# ─── Main Simulation Class ────────────────────────────────────────────────────
class GridSimulation:
    """
    Discrete-time 4×4 grid traffic simulation.

    Parameters
    ----------
    scenario_key : str
        One of "peak", "offpeak", "disruption".
    seed : int
        Random seed for reproducibility.
    controller : callable, optional
        Function (intersections, t) → dict[node_id, phase_action].
        If None, the simulation runs with no control (for warm-up only).
    duration : int
        Simulation duration in seconds.
    """

    def __init__(
        self,
        scenario_key: str,
        seed: int = 42,
        controller=None,
        duration: int = SIMULATION_DURATION,
    ):
        self.scenario_key = scenario_key
        self.scenario = SCENARIOS[scenario_key]
        self.seed = seed
        self.controller = controller
        self.duration = duration

        random.seed(seed)
        np.random.seed(seed)
        Vehicle._id_counter = 0

        self.t: int = 0                         # current simulation second

        # Build intersections
        self.intersections: Dict[str, IntersectionState] = {}
        for r in range(GRID_ROWS):
            for c in range(GRID_COLS):
                nid = f"n_{r}_{c}"
                self.intersections[nid] = IntersectionState(r, c)

        # Global vehicle records
        self.active_vehicles: List[Vehicle] = []
        self.completed_vehicles: List[Vehicle] = []

        # Demand rate: vehicles/second entering the network (total)
        capacity = SATURATION_FLOW_PS * 2 * (GRID_ROWS + GRID_COLS) * 2
        self.demand_rate_vps = self.scenario["demand_factor"] * capacity / 4.0

        # Step-by-step log for metrics
        self.step_log: List[dict] = []

    # ─── Demand ───────────────────────────────────────────────────────────────
    def _current_demand(self) -> float:
        """Return demand rate (veh/s) at current time step."""
        if self.scenario.get("disruption") and self.t >= self.scenario["disruption_time"]:
            cap = SATURATION_FLOW_PS * 2 * (GRID_ROWS + GRID_COLS) * 2
            return self.scenario["disruption_demand"] * cap / 4.0
        return self.demand_rate_vps

    def _generate_vehicles(self):
        """Poisson vehicle arrivals at perimeter entry edges."""
        rate = self._current_demand()
        num_entries = 2 * (GRID_ROWS + GRID_COLS)
        rate_per_entry = rate / num_entries if num_entries > 0 else 0

        entries = []
        for c in range(GRID_COLS):
            entries.append(("N", c))   # enter from North side → row=GRID_ROWS-1
            entries.append(("S", c))   # enter from South side → row=0
        for r in range(GRID_ROWS):
            entries.append(("W", r))   # enter from West side → col=0
            entries.append(("E", r))   # enter from East side → col=GRID_COLS-1

        if len(self.active_vehicles) >= 2000:
            return

        for side, idx in entries:
            if random.random() < rate_per_entry:
                veh = self._spawn_vehicle(side, idx)
                if veh:
                    self.active_vehicles.append(veh)

    def _spawn_vehicle(self, entry_side: str, entry_idx: int) -> Optional[Vehicle]:
        """Create a vehicle entering from one perimeter edge."""
        if entry_side == "N":
            start_row, start_col, approach = GRID_ROWS - 1, entry_idx, "N"
        elif entry_side == "S":
            start_row, start_col, approach = 0, entry_idx, "S"
        elif entry_side == "W":
            start_row, start_col, approach = entry_idx, 0, "W"
        else:  # E
            start_row, start_col, approach = entry_idx, GRID_COLS - 1, "E"

        # Random destination: pick a different perimeter exit
        exit_entries = self._all_exits(exclude=(entry_side, entry_idx))
        if not exit_entries:
            return None
        dest_side, dest_idx = random.choice(exit_entries)
        route = self._build_route(start_row, start_col, approach,
                                  dest_side, dest_idx)
        veh = Vehicle(f"{entry_side}_{entry_idx}", route)
        veh.spawn_time = self.t
        # Place in first intersection queue immediately
        if route:
            r, c, appr = route[0]
            self.intersections[f"n_{r}_{c}"].queues[appr].append(veh)
        return veh

    def _all_exits(self, exclude: Tuple) -> List[Tuple]:
        exits = []
        for c in range(GRID_COLS):
            exits.append(("N", c)); exits.append(("S", c))
        for r in range(GRID_ROWS):
            exits.append(("W", r)); exits.append(("E", r))
        return [e for e in exits if e != exclude]

    def _build_route(
        self,
        start_row: int, start_col: int, entry_approach: str,
        dest_side: str, dest_idx: int,
    ) -> List[Tuple[int, int, str]]:
        """
        Compute a simple Manhattan route through the grid.
        Returns list of (row, col, approach_direction) tuples.
        The approach_direction is the direction FROM WHICH the vehicle arrives.
        """
        if dest_side == "N":
            end_row, end_col = GRID_ROWS - 1, dest_idx
        elif dest_side == "S":
            end_row, end_col = 0, dest_idx
        elif dest_side == "W":
            end_row, end_col = start_row, 0
        else:  # E
            end_row, end_col = start_row, GRID_COLS - 1

        route = [(start_row, start_col, entry_approach)]
        r, c = start_row, start_col

        # Move column first (E-W), then row (N-S) — simple Manhattan
        while c != end_col:
            if c < end_col:
                c += 1
                route.append((r, c, "W"))   # arrived from West
            else:
                c -= 1
                route.append((r, c, "E"))   # arrived from East

        while r != end_row:
            if r < end_row:
                r += 1
                route.append((r, c, "S"))   # arrived from South
            else:
                r -= 1
                route.append((r, c, "N"))   # arrived from North

        return route

    # ─── Signal update ─────────────────────────────────────────────────────────
    def _update_signals(self, phase_commands: dict):
        """
        Apply phase commands from the controller.

        phase_commands : dict[node_id, int]  target phase for each intersection.
        Only phase changes that are valid (no skipping yellow) are applied.
        """
        for nid, state in self.intersections.items():
            target = phase_commands.get(nid)
            if target is None:
                target = state.phase   # hold current phase

            state.phase_timer += 1.0

            if state.phase in GREEN_PHASES:
                # Can only switch to yellow, not skip to other green
                if target != state.phase and state.phase_timer >= MIN_GREEN:
                    # Switch to yellow
                    state.phase = (state.phase + 1) % 4  # next phase = yellow
                    state.phase_timer = 0.0
            else:
                # In yellow phase: auto-advance after YELLOW_DURATION
                if state.phase_timer >= YELLOW_DURATION:
                    state.phase = (state.phase + 1) % 4
                    state.phase_timer = 0.0

    # ─── Vehicle movement ──────────────────────────────────────────────────────
    def _discharge_queues(self):
        """
        Discharge vehicles through green lights at saturation flow.
        Each green approach can discharge ≈ SATURATION_FLOW_PS vehicles/s.
        """
        for nid, state in self.intersections.items():
            phase = state.phase
            if phase == PHASE_NS_GREEN:
                active_approaches = NS_APPROACHES
            elif phase == PHASE_EW_GREEN:
                active_approaches = EW_APPROACHES
            else:
                active_approaches = ()

            for appr in active_approaches:
                queue = state.queues[appr]
                # How many can depart this step?
                departures = min(len(queue), max(1, int(SATURATION_FLOW_PS)))
                for _ in range(departures):
                    if not queue:
                        break
                    veh = queue.pop(0)
                    veh.route_idx += 1
                    if veh.route_idx >= len(veh.route):
                        # Vehicle exits the network
                        veh.completed = True
                        veh.completed = True
                        self.completed_vehicles.append(veh)
                    else:
                        # Put in transit to next intersection
                        r, c, next_appr = veh.route[veh.route_idx]
                        arrival_t = self.t + TRAVEL_TIME_S
                        next_nid = f"n_{r}_{c}"
                        self.intersections[next_nid].in_transit[next_appr].append(
                            (arrival_t, veh)
                        )

    def _advance_transit(self):
        """Move vehicles from in-transit to queue when travel time elapsed."""
        for nid, state in self.intersections.items():
            for appr, transit_list in state.in_transit.items():
                arrived = [item for item in transit_list if item[0] <= self.t]
                remaining = [item for item in transit_list if item[0] > self.t]
                state.in_transit[appr] = remaining
                for (_, veh) in arrived:
                    state.queues[appr].append(veh)

    def _accumulate_wait(self):
        """Increment waiting time for all vehicles queued at red lights."""
        for nid, state in self.intersections.items():
            phase = state.phase
            if phase == PHASE_NS_GREEN:
                red_approaches = EW_APPROACHES
            elif phase == PHASE_EW_GREEN:
                red_approaches = NS_APPROACHES
            else:
                red_approaches = list(state.queues.keys())  # all wait in yellow

            for appr in red_approaches:
                for veh in state.queues[appr]:
                    veh.wait_time += 1.0
                    state.cumulative_wait += 1.0

    # ─── Metric snapshot ──────────────────────────────────────────────────────
    def _snapshot(self):
        """Record per-step metrics."""
        total_queue = sum(s.total_queue() for s in self.intersections.values())
        self.step_log.append({
            "t": self.t,
            "queue_total": total_queue,
            "active": len(self.active_vehicles),
            "completed": len(self.completed_vehicles),
        })

    # ─── Main loop ────────────────────────────────────────────────────────────
    def step(self, phase_commands: Optional[dict] = None) -> dict:
        """Advance simulation by one second. Returns observation dict."""
        if phase_commands is None:
            phase_commands = {}

        self._advance_transit()
        self._generate_vehicles()
        self._update_signals(phase_commands)
        self._discharge_queues()
        self._accumulate_wait()
        self._snapshot()
        self.t += 1

        return self._get_observations()

    def _get_observations(self) -> dict:
        """Return per-intersection observation vectors."""
        return {nid: s.get_obs() for nid, s in self.intersections.items()}

    def run_full(self) -> dict:
        """
        Run the full simulation for `self.duration` steps with the attached
        controller.  Returns the results dict.
        """
        obs = self._get_observations()
        for step_t in range(self.duration):
            if self.controller is not None:
                phase_cmds = self.controller.act(obs, self)
            else:
                phase_cmds = {}
            obs = self.step(phase_cmds)

        return self.collect_results()

    # ─── Results ──────────────────────────────────────────────────────────────
    def collect_results(self) -> dict:
        """
        Compute and return the six performance metrics described in §3.8.
        """
        all_vehicles = self.completed_vehicles + [
            v for v in self.active_vehicles if not v.completed
        ]
        wait_times = [v.wait_time for v in all_vehicles if v.wait_time >= 0]
        avwt = float(np.mean(wait_times)) if wait_times else 0.0
        throughput = len(self.completed_vehicles)

        # Per-lane waiting for Jain's Fairness Index
        per_lane_wait = []
        for nid, state in self.intersections.items():
            per_lane_wait.append(state.cumulative_wait / max(self.t, 1))

        # Queue-length time-series per intersection (for SHAP features)
        intersection_obs = {
            nid: {
                "final_queues": state.queue_lengths(),
                "cumulative_wait": state.cumulative_wait,
                "decisions": state.decisions,
            }
            for nid, state in self.intersections.items()
        }

        return {
            "avwt": avwt,
            "throughput": throughput,
            "per_lane_wait": per_lane_wait,
            "step_log": self.step_log,
            "intersection_obs": intersection_obs,
            "duration": self.t,
        }

    def get_global_obs(self) -> np.ndarray:
        """Flat observation across all intersections (for global DQN)."""
        obs_list = []
        for r in range(GRID_ROWS):
            for c in range(GRID_COLS):
                obs_list.append(self.intersections[f"n_{r}_{c}"].get_obs())
        return np.concatenate(obs_list)
