"""
Experiment Runner — §3.7

Runs the full factorial experiment:
    4 governance models × 3 scenarios × 30 random-seed replications
    = 360 simulation runs

Each run:
  1. Instantiates the appropriate controller (deterministic / human / AI / hybrid)
  2. Runs the GridSimulation for SIMULATION_DURATION seconds
  3. Computes the six performance metrics
  4. Appends a row to the results DataFrame

Progress is streamed to stdout and the results DataFrame is saved as CSV
after every governance × scenario block so partial results are not lost.
"""

from __future__ import annotations

import os
import sys
import time
from pathlib import Path
from typing import Dict, Optional

import pandas as pd

from config import (
    SCENARIOS, GOVERNANCE_MODELS, NUM_RUNS, SEED_BASE,
    SIMULATION_DURATION, TRAINED_MODEL_PATH,
)
from metrics.compute import per_run_record


# ─── Controller factories ─────────────────────────────────────────────────────
def make_controller(
    governance: str,
    scenario_key: str,
    seed: int,
    dqn_path: Optional[str] = None,
):
    """Instantiate the appropriate controller for a single run."""
    if governance == "deterministic":
        from models.deterministic import DeterministicController
        ctrl = DeterministicController(scenario_key)
        return ctrl

    if governance == "human":
        from models.human_agent import HumanAgentController
        return HumanAgentController(seed=seed)

    if governance == "ai":
        from models.ai_dqn import DQNController
        path = dqn_path or TRAINED_MODEL_PATH
        if not os.path.exists(path) and not os.path.exists(path + ".zip"):
            raise FileNotFoundError(
                f"Trained DQN model not found at '{path}'.\n"
                f"Run:  python training/train_dqn.py --quick 50000"
            )
        return DQNController.load(path, seed=seed)

    if governance == "hybrid":
        from models.hybrid import HybridController
        path = dqn_path or TRAINED_MODEL_PATH
        # If DQN not trained, hybrid falls back to det+human 2-of-2 vote
        if not os.path.exists(path) and not os.path.exists(path + ".zip"):
            path = None
        return HybridController(scenario_key, dqn_path=path, seed=seed)

    raise ValueError(f"Unknown governance model: {governance!r}")


# ─── Single run ───────────────────────────────────────────────────────────────
def run_one(
    governance: str,
    scenario_key: str,
    run_idx: int,
    dqn_path: Optional[str] = None,
    duration: int = SIMULATION_DURATION,
) -> dict:
    """Execute one simulation run and return a metrics dict."""
    from simulation.grid_sim import GridSimulation

    seed = SEED_BASE + run_idx
    ctrl = make_controller(governance, scenario_key, seed, dqn_path)

    sim = GridSimulation(
        scenario_key=scenario_key,
        seed=seed,
        controller=ctrl,
        duration=duration,
    )
    results = sim.run_full()

    return per_run_record(
        governance_model=governance,
        scenario_key=scenario_key,
        run_idx=run_idx,
        results=results,
        controller=ctrl,
    )


# ─── Full experiment ──────────────────────────────────────────────────────────
def run_experiment(
    governance_models: Optional[list] = None,
    scenarios: Optional[list] = None,
    n_runs: int = NUM_RUNS,
    dqn_path: Optional[str] = None,
    duration: int = SIMULATION_DURATION,
    output_dir: str = "results",
) -> pd.DataFrame:
    """
    Run the full experiment and return a DataFrame of results.

    Parameters
    ----------
    governance_models : list, optional   — subset of GOVERNANCE_MODELS
    scenarios         : list, optional   — subset of SCENARIOS keys
    n_runs            : int              — replications per condition
    dqn_path          : str, optional    — path to trained DQN model
    duration          : int              — seconds per simulation run
    output_dir        : str              — directory to save CSV results

    Returns
    -------
    pd.DataFrame with one row per run and columns:
        governance, scenario, run, avwt, throughput,
        jain_fairness_index, explainability_score
    """
    gov_list = governance_models or GOVERNANCE_MODELS
    scen_list = scenarios or list(SCENARIOS.keys())
    Path(output_dir).mkdir(parents=True, exist_ok=True)

    records = []
    total = len(gov_list) * len(scen_list) * n_runs
    done = 0
    t0 = time.time()

    for governance in gov_list:
        for scenario_key in scen_list:
            print(
                f"\n  [{governance:>13s} × {scenario_key:<10s}]  "
                f"{n_runs} runs × {duration}s each"
            )
            for run_idx in range(n_runs):
                try:
                    rec = run_one(
                        governance, scenario_key, run_idx,
                        dqn_path=dqn_path, duration=duration,
                    )
                    records.append(rec)
                except Exception as e:
                    print(f"    Run {run_idx} FAILED: {e}")
                    records.append({
                        "governance": governance,
                        "scenario": scenario_key,
                        "run": run_idx,
                        "avwt": None,
                        "throughput": None,
                        "jain_fairness_index": None,
                        "explainability_score": None,
                    })

                done += 1
                elapsed = time.time() - t0
                rate = done / elapsed
                eta = (total - done) / rate if rate > 0 else 0
                print(
                    f"    run {run_idx+1:>2}/{n_runs}  |  "
                    f"{done}/{total} done  |  "
                    f"ETA {eta/60:.1f} min",
                    end="\r",
                )

            # Save partial results after each governance×scenario block
            df_partial = pd.DataFrame(records)
            csv_path = Path(output_dir) / "results_partial.csv"
            df_partial.to_csv(csv_path, index=False)

    df = pd.DataFrame(records)
    csv_final = Path(output_dir) / "results.csv"
    df.to_csv(csv_final, index=False)
    print(f"\n\n  Results saved → {csv_final}")
    return df
