"""
DQN Training Script — §3.6.3

Train the DQN agent for 500,000 steps on random demand profiles, then
save the model for use in the main experiment.

Usage:
    python training/train_dqn.py                   # full 500k run
    python training/train_dqn.py --quick 10000     # quick test / debug
"""

from __future__ import annotations

import argparse
import sys
import os

# Make project root importable
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from config import DQN_TRAIN_STEPS, TRAINED_MODEL_PATH
from models.ai_dqn import DQNController


def main():
    parser = argparse.ArgumentParser(description="Train the DQN traffic controller.")
    parser.add_argument(
        "--steps", type=int, default=DQN_TRAIN_STEPS,
        help=f"Training timesteps (default: {DQN_TRAIN_STEPS})",
    )
    parser.add_argument(
        "--quick", type=int, default=None,
        help="Override --steps with a small number for quick testing.",
    )
    parser.add_argument(
        "--seed", type=int, default=42,
        help="Random seed for training.",
    )
    parser.add_argument(
        "--output", type=str, default=TRAINED_MODEL_PATH,
        help=f"Output model path (default: {TRAINED_MODEL_PATH})",
    )
    parser.add_argument(
        "--verbose", type=int, default=1,
        help="stable-baselines3 verbosity (0=quiet, 1=info, 2=debug).",
    )
    args = parser.parse_args()

    steps = args.quick if args.quick is not None else args.steps
    print(f"\n{'='*60}")
    print(f"  DQN Traffic Controller Training")
    print(f"  Steps:  {steps:,}")
    print(f"  Seed:   {args.seed}")
    print(f"  Output: {args.output}")
    print(f"{'='*60}\n")

    ctrl = DQNController.train(
        total_timesteps=steps,
        seed=args.seed,
        save_path=args.output,
        verbose=args.verbose,
    )

    print("\n  Training complete.")
    print(f"  Model saved to: {args.output}")
    print(f"\n  To use in experiments:")
    print(f"    python run_experiment.py --model {args.output}")


if __name__ == "__main__":
    main()
