"""
Main Experiment Entry Point

Runs the complete simulation experiment described in §3.7:
  4 governance models × 3 scenarios × 30 replications

Usage examples:
    # Full experiment (trains DQN first if not already done):
    python run_experiment.py

    # Quick test (5 runs, 60-second simulations, 10k DQN steps):
    python run_experiment.py --quick

    # Use pre-trained DQN model:
    python run_experiment.py --model trained_models/dqn_traffic.zip

    # Single governance model, one scenario:
    python run_experiment.py --governance ai --scenario peak --runs 5

    # Statistical analysis only (requires results/results.csv):
    python run_experiment.py --analyze-only
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

import pandas as pd


def parse_args():
    p = argparse.ArgumentParser(
        description="Smart City Traffic Governance Simulation — Mubasharati Jannat (30141941)"
    )
    p.add_argument("--quick", action="store_true",
                   help="Short test run (5 replications, 60s simulation, 10k DQN steps)")
    p.add_argument("--governance", nargs="+",
                   choices=["deterministic", "human", "ai", "hybrid"],
                   help="Run specific governance models only")
    p.add_argument("--scenario", nargs="+",
                   choices=["peak", "offpeak", "disruption"],
                   help="Run specific scenarios only")
    p.add_argument("--runs", type=int, default=None,
                   help="Number of replications per condition")
    p.add_argument("--duration", type=int, default=None,
                   help="Simulation duration in seconds (default: 3600)")
    p.add_argument("--model", type=str, default=None,
                   help="Path to pre-trained DQN model")
    p.add_argument("--train-steps", type=int, default=None,
                   help="DQN training steps (overrides config)")
    p.add_argument("--output", type=str, default="results",
                   help="Results directory (default: results/)")
    p.add_argument("--analyze-only", action="store_true",
                   help="Run statistical analysis on existing results/results.csv")
    p.add_argument("--no-train", action="store_true",
                   help="Skip DQN training (use existing model or fallback)")
    return p.parse_args()


def ensure_dqn_trained(train_steps: int, model_path: str) -> str:
    """Train DQN if no model exists at model_path, return model path."""
    from config import TRAINED_MODEL_PATH
    path = model_path or TRAINED_MODEL_PATH

    if os.path.exists(path) or os.path.exists(path + ".zip"):
        print(f"  DQN model found at: {path}  (skipping training)")
        return path

    print(f"  DQN model not found — training for {train_steps:,} steps …")
    from models.ai_dqn import DQNController
    DQNController.train(
        total_timesteps=train_steps,
        save_path=path,
        verbose=0,
    )
    return path


def print_summary(df: pd.DataFrame):
    """Print a formatted summary table of mean metrics per condition."""
    print("\n" + "=" * 80)
    print("  RESULTS SUMMARY (means across replications)")
    print("=" * 80)

    metrics = [
        ("avwt", "Avg Wait Time (s)"),
        ("throughput", "Throughput (veh)"),
        ("jain_fairness_index", "Jain Fairness Index"),
        ("explainability_score", "Explainability Score"),
    ]

    for sc in df["scenario"].unique():
        print(f"\n  Scenario: {sc.upper()}")
        sub = df[df["scenario"] == sc]
        rows = []
        for gov in df["governance"].unique():
            g_sub = sub[sub["governance"] == gov]
            row = {"Governance": gov.capitalize()}
            for col, _ in metrics:
                vals = g_sub[col].dropna()
                row[col] = f"{vals.mean():.2f} ± {vals.std():.2f}" if len(vals) else "N/A"
            rows.append(row)
        out = pd.DataFrame(rows).set_index("Governance")
        out.columns = [label for _, label in metrics]
        print(out.to_string())

    print("\n" + "=" * 80)


def main():
    args = parse_args()

    # ── Quick-test overrides ───────────────────────────────────────────────────
    n_runs = args.runs or (5 if args.quick else 30)
    duration = args.duration or (60 if args.quick else 3600)
    train_steps = args.train_steps or (10_000 if args.quick else 500_000)
    gov_list = args.governance
    scen_list = args.scenario
    output_dir = args.output

    print("\n" + "=" * 60)
    print("  Smart City Traffic Governance Simulation")
    print("  Mubasharati Jannat — Student ID 30141941")
    print("=" * 60)
    print(f"\n  Runs per condition : {n_runs}")
    print(f"  Sim duration       : {duration}s  ({duration/3600:.2f}h)")
    print(f"  Governance models  : {gov_list or 'all'}")
    print(f"  Scenarios          : {scen_list or 'all'}")
    print(f"  Output directory   : {output_dir}/")

    # ── Analyze-only mode ─────────────────────────────────────────────────────
    if args.analyze_only:
        csv_path = Path(output_dir) / "results.csv"
        if not csv_path.exists():
            print(f"\n  ERROR: {csv_path} not found.  Run the experiment first.")
            sys.exit(1)
        df = pd.read_csv(csv_path)
        print_summary(df)
        from analysis.statistics import run_all_analyses
        run_all_analyses(df, output_dir=output_dir)
        return

    # ── DQN training ──────────────────────────────────────────────────────────
    needs_dqn = (not gov_list) or any(
        g in (gov_list or []) for g in ("ai", "hybrid")
    )
    dqn_path = args.model
    if needs_dqn and not args.no_train:
        dqn_path = ensure_dqn_trained(train_steps, dqn_path)

    # ── Run experiment ────────────────────────────────────────────────────────
    from simulation.runner import run_experiment
    df = run_experiment(
        governance_models=gov_list,
        scenarios=scen_list,
        n_runs=n_runs,
        dqn_path=dqn_path,
        duration=duration,
        output_dir=output_dir,
    )

    # ── Summary & stats ───────────────────────────────────────────────────────
    print_summary(df)

    from analysis.statistics import run_all_analyses
    try:
        run_all_analyses(df, output_dir=output_dir)
    except ImportError as e:
        print(f"\n  statsmodels not installed — skipping Tukey HSD: {e}")
        print("  Install with: pip install statsmodels --break-system-packages")

    print("\n  Done.\n")


if __name__ == "__main__":
    main()
