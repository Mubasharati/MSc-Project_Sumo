"""
Deterministic Governance Model — §3.6.1

Implements Webster's (1958) classical fixed-time signal control.

Webster's optimal cycle formula:
    C_opt = (1.5 × L + 5) / (1 − Σ y_i)

where:
    L  = total lost time per cycle  (number_of_phases × lost_time_per_phase)
    y_i = q_i / s  = approach volume / saturation flow

Green splits are proportional to the y_i values.

Timings are pre-computed from *historical* (average) demand at startup and
held fixed throughout the simulation — they do not adapt to real-time data.
This is the key characteristic of deterministic governance: full transparency
because the complete timing plan is a published document.

Explainability Score: 1.0 (perfectly transparent — anyone can compute the
next signal state from the published timing sheet).
"""

from __future__ import annotations

import math
from typing import Dict, Optional

from config import (
    SATURATION_FLOW_PS, YELLOW_DURATION, LOST_TIME_PER_PHASE,
    MIN_GREEN, GRID_ROWS, GRID_COLS, SCENARIOS,
)
from simulation.grid_sim import (
    PHASE_NS_GREEN, PHASE_NS_YELLOW, PHASE_EW_GREEN, PHASE_EW_YELLOW,
)


class DeterministicController:
    """
    Pre-computes Webster optimal timing from historical (average) demand,
    then runs a fixed phase plan throughout the entire simulation.

    Parameters
    ----------
    scenario_key : str
        Determines historical demand used for timing computation.
    """

    EXPLAINABILITY_SCORE = 1.0   # §3.8.2 — fully deterministic ⇒ ES = 1.0

    def __init__(self, scenario_key: str):
        self.scenario_key = scenario_key
        # Pre-compute timings once from average demand
        self._timing = self._compute_timing(scenario_key)
        # Per-intersection phase state (for fixed-cycle tracking)
        self._phase: Dict[str, int] = {}
        self._phase_timer: Dict[str, float] = {}
        self._initialized = False

    # ─── Webster formula ──────────────────────────────────────────────────────
    @staticmethod
    def _compute_timing(scenario_key: str) -> dict:
        """
        Apply Webster (1958) to derive optimal cycle length and green splits.

        Returns dict with keys: cycle, g_NS, g_EW
        """
        scen = SCENARIOS[scenario_key]
        demand_factor = scen["demand_factor"]

        # Approach volume: demand fraction × saturation flow
        y_NS = demand_factor * 0.55   # historically NS carries ~55% of flow
        y_EW = demand_factor * 0.45   # historically EW carries ~45% of flow

        # Cap y_i at 0.95 to avoid division by zero / unrealistic cycle
        y_NS = min(y_NS, 0.95)
        y_EW = min(y_EW, 0.95)

        num_phases = 2   # NS green + EW green (yellows are fixed transition)
        L = num_phases * LOST_TIME_PER_PHASE  # total lost time per cycle

        sum_y = y_NS + y_EW
        if sum_y >= 1.0:
            # Over-saturated — use a long fixed cycle
            C = 120.0
        else:
            C = (1.5 * L + 5.0) / (1.0 - sum_y)
            C = max(C, 40.0)   # minimum cycle
            C = min(C, 120.0)  # maximum cycle

        # Effective green time (available for vehicles)
        G = C - 2 * YELLOW_DURATION - L
        G = max(G, 2 * MIN_GREEN)

        # Green splits proportional to y_i
        g_NS = max(MIN_GREEN, round(G * y_NS / sum_y))
        g_EW = max(MIN_GREEN, round(G * y_EW / sum_y))

        return {
            "cycle": C,
            "g_NS": g_NS,
            "g_EW": g_EW,
            "yellow": YELLOW_DURATION,
        }

    # ─── Timing plan ──────────────────────────────────────────────────────────
    @property
    def timing_plan(self) -> dict:
        """Published timing plan (full transparency)."""
        return {
            "model": "Deterministic (Webster 1958)",
            "cycle_length_s": self._timing["cycle"],
            "ns_green_s": self._timing["g_NS"],
            "ew_green_s": self._timing["g_EW"],
            "yellow_s": self._timing["yellow"],
            "note": "Fixed plan computed from historical demand; does not adapt.",
        }

    # ─── Controller interface ─────────────────────────────────────────────────
    def _init_phases(self, obs: dict):
        """Initialise per-intersection state on first call."""
        for nid in obs:
            self._phase[nid] = PHASE_NS_GREEN
            self._phase_timer[nid] = 0.0
        self._initialized = True

    def act(self, obs: dict, sim=None) -> Dict[str, int]:
        """
        Advance each intersection through the fixed-cycle plan and return
        the target phase for this time step.

        Parameters
        ----------
        obs  : dict[node_id, np.ndarray]  — current observations (unused here)
        sim  : GridSimulation              — simulation handle (unused here)

        Returns
        -------
        dict[node_id, int]  — target phase per intersection
        """
        if not self._initialized:
            self._init_phases(obs)

        commands: Dict[str, int] = {}
        timing = self._timing

        for nid in obs:
            phase = self._phase[nid]
            timer = self._phase_timer[nid]

            # Advance timer
            timer += 1.0

            # Determine phase duration
            if phase == PHASE_NS_GREEN:
                duration = timing["g_NS"]
            elif phase == PHASE_EW_GREEN:
                duration = timing["g_EW"]
            else:
                duration = timing["yellow"]   # yellow phases

            # Transition?
            if timer >= duration:
                phase = (phase + 1) % 4
                timer = 0.0

            self._phase[nid] = phase
            self._phase_timer[nid] = timer
            commands[nid] = phase

        return commands

    def reset(self):
        """Reset controller state (call before a new simulation run)."""
        self._phase.clear()
        self._phase_timer.clear()
        self._initialized = False

    def __repr__(self):
        t = self._timing
        return (
            f"DeterministicController(cycle={t['cycle']:.0f}s, "
            f"g_NS={t['g_NS']}s, g_EW={t['g_EW']}s)"
        )
