"""
Human Governance Model — §3.6.2

Implements a scripted adaptive agent that mimics a traffic control-centre
operator, with the following characteristics:

1.  Queue monitoring — reads induction-loop queue lengths every 6 seconds
    (HUMAN_REACTION_TIME) and compares NS vs EW loads.
2.  Heuristic rules — if the opposing direction has a queue ≥ threshold,
    the operator extends the current green or issues a phase change.
3.  Conservative minimum green — always respects a MIN_GREEN floor.
4.  Human error — 5 % of decisions are randomised (per §3.6.2).
5.  Decision logging — every decision writes a log entry for explainability.

Explainability Score: computed as the fraction of decisions where the
triggering rule can be clearly identified from the decision log (§3.8.2).
"""

from __future__ import annotations

import random
from typing import Dict, List

import numpy as np

from config import (
    MIN_GREEN, YELLOW_DURATION, HUMAN_REACTION_TIME, HUMAN_ERROR_RATE,
)
from simulation.grid_sim import (
    PHASE_NS_GREEN, PHASE_NS_YELLOW, PHASE_EW_GREEN, PHASE_EW_YELLOW,
)

# Queue length threshold that triggers a phase change (vehicles)
QUEUE_THRESHOLD = 5


class HumanAgentController:
    """
    Scripted adaptive human-operator proxy.

    Parameters
    ----------
    seed : int
        Random seed for the 5 % error injection.
    """

    def __init__(self, seed: int = 42):
        self.seed = seed
        random.seed(seed)
        self._phase: Dict[str, int] = {}
        self._phase_timer: Dict[str, float] = {}
        self._last_check: Dict[str, float] = {}  # last reaction time
        self._decision_log: List[dict] = []
        self._initialized = False
        self._step = 0

    # ─── Controller interface ─────────────────────────────────────────────────
    def _init(self, obs: dict):
        for nid in obs:
            self._phase[nid] = PHASE_NS_GREEN
            self._phase_timer[nid] = 0.0
            self._last_check[nid] = 0.0
        self._initialized = True

    def act(self, obs: dict, sim=None) -> Dict[str, int]:
        """
        Returns target phase for each intersection based on heuristic rules.
        """
        if not self._initialized:
            self._init(obs)

        commands: Dict[str, int] = {}
        self._step += 1

        for nid, observation in obs.items():
            phase = self._phase[nid]
            timer = self._phase_timer[nid]
            timer += 1.0

            # ── Yellow phase: auto-advance (operator cannot interrupt yellow) ──
            if phase in (PHASE_NS_YELLOW, PHASE_EW_YELLOW):
                if timer >= YELLOW_DURATION:
                    phase = (phase + 1) % 4
                    timer = 0.0
                self._phase[nid] = phase
                self._phase_timer[nid] = timer
                commands[nid] = phase
                continue

            # ── Green phase: operator checks every HUMAN_REACTION_TIME s ──────
            time_since_check = self._step - self._last_check.get(nid, 0)
            if time_since_check < HUMAN_REACTION_TIME or timer < MIN_GREEN:
                # Operator hasn't looked yet or minimum green not satisfied
                self._phase[nid] = phase
                self._phase_timer[nid] = timer
                commands[nid] = phase
                continue

            # ── Operator assessment ───────────────────────────────────────────
            self._last_check[nid] = self._step

            q_NS = int(observation[0]) + int(observation[1])   # N + S queues
            q_EW = int(observation[2]) + int(observation[3])   # E + W queues

            currently_NS = (phase == PHASE_NS_GREEN)
            current_queue = q_NS if currently_NS else q_EW
            opposing_queue = q_EW if currently_NS else q_NS

            # ── Human error injection (5 % random decisions) ──────────────────
            if random.random() < HUMAN_ERROR_RATE:
                # Random error: flip the phase regardless of queue
                new_phase = (phase + 1) % 4   # switch to yellow
                rule = "ERROR_RANDOM"
            elif opposing_queue >= QUEUE_THRESHOLD and opposing_queue > current_queue:
                # Rule: opposing queue is long → switch phase
                new_phase = (phase + 1) % 4   # switch to yellow
                rule = f"SWITCH_OPPOSING_Q={opposing_queue}>CURRENT_Q={current_queue}"
            else:
                # Rule: hold the current green
                new_phase = phase
                rule = f"HOLD_CURRENT_Q={current_queue}"

            # Log decision
            self._decision_log.append({
                "nid": nid,
                "step": self._step,
                "phase": phase,
                "q_NS": q_NS,
                "q_EW": q_EW,
                "rule": rule,
                "identifiable": rule != "ERROR_RANDOM",
                "action": new_phase,
            })

            if new_phase != phase:
                phase = new_phase
                timer = 0.0

            self._phase[nid] = phase
            self._phase_timer[nid] = timer
            commands[nid] = phase

        return commands

    # ─── Explainability Score ─────────────────────────────────────────────────
    def explainability_score(self) -> float:
        """
        ES = fraction of decisions where the triggering rule is identifiable
        (i.e., not a random error).  Per §3.8.2.
        """
        if not self._decision_log:
            return 1.0   # no phase changes ⇒ fully predictable hold
        identifiable = sum(1 for d in self._decision_log if d["identifiable"])
        return identifiable / len(self._decision_log)

    def reset(self, seed: int = None):
        self._phase.clear()
        self._phase_timer.clear()
        self._last_check.clear()
        self._decision_log.clear()
        self._initialized = False
        self._step = 0
        if seed is not None:
            self.seed = seed
            random.seed(seed)

    def __repr__(self):
        return (
            f"HumanAgentController(reaction_time={HUMAN_REACTION_TIME}s, "
            f"error_rate={HUMAN_ERROR_RATE:.0%}, "
            f"queue_threshold={QUEUE_THRESHOLD})"
        )
