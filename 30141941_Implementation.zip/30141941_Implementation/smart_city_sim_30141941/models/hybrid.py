"""
Hybrid Governance Model — §3.6.4

Combines all three governance approaches via weighted majority voting:

    vote_D  — deterministic phase (Webster fixed plan)
    vote_H  — human-agent phase (heuristic rule-based)
    vote_AI — DQN phase

The winning phase is selected by majority (2-out-of-3 rule):
    If any two controllers agree → winner
    If all three disagree        → fall back to deterministic (safety)

This design follows Streitz (2019) and Bosco et al. (2026): AI should
complement human decision-making rather than replace it, while the
deterministic rule-based signal assures baseline safety.

Explainability Score: weighted average of the three component ESs,
proportional to how frequently each model "won" the vote.
"""

from __future__ import annotations

from typing import Dict, Tuple, Optional

import numpy as np

from config import MIN_GREEN, YELLOW_DURATION
from simulation.grid_sim import (
    PHASE_NS_GREEN, PHASE_NS_YELLOW, PHASE_EW_GREEN, PHASE_EW_YELLOW,
    GREEN_PHASES,
)
from models.deterministic import DeterministicController
from models.human_agent import HumanAgentController
from models.ai_dqn import DQNController


class HybridController:
    """
    Majority-voting hybrid of deterministic, human, and AI controllers.

    Parameters
    ----------
    scenario_key : str
        Passed to DeterministicController for timing pre-computation.
    dqn_path : str, optional
        Path to a pre-trained DQN weights file.
    seed : int
        Random seed for the HumanAgentController.
    """

    def __init__(
        self,
        scenario_key: str,
        dqn_path: Optional[str] = None,
        seed: int = 42,
    ):
        self.scenario_key = scenario_key
        self.seed = seed

        self.det = DeterministicController(scenario_key)
        self.human = HumanAgentController(seed=seed)

        if dqn_path is not None:
            self.ai = DQNController.load(dqn_path, seed=seed)
        else:
            # If no model exists yet, we'll use a simple rule-based fallback
            self.ai = None
            print("  [Hybrid] No DQN model found — using det+human 2-of-2 vote.")

        # Vote tallies per intersection (for reporting)
        self._vote_counts: Dict[str, Dict[str, int]] = {}

    # ─── Controller interface ─────────────────────────────────────────────────
    def act(self, obs: dict, sim=None) -> Dict[str, int]:
        """
        Collect a phase decision from each sub-controller, apply majority vote.
        """
        det_cmds = self.det.act(obs, sim)
        hum_cmds = self.human.act(obs, sim)
        ai_cmds = self.ai.act(obs, sim) if self.ai is not None else det_cmds

        commands: Dict[str, int] = {}

        for nid in obs:
            v_d = det_cmds.get(nid, PHASE_NS_GREEN)
            v_h = hum_cmds.get(nid, PHASE_NS_GREEN)
            v_a = ai_cmds.get(nid, PHASE_NS_GREEN)

            winner, method = self._majority_vote(v_d, v_h, v_a)
            commands[nid] = winner

            # Tally
            if nid not in self._vote_counts:
                self._vote_counts[nid] = {"det": 0, "human": 0, "ai": 0, "fallback": 0}
            self._vote_counts[nid][method] += 1

        return commands

    @staticmethod
    def _majority_vote(v_d: int, v_h: int, v_a: int) -> Tuple[int, str]:
        """
        Return (winning_phase, winning_method).

        If any two match → majority.
        All three differ → deterministic safety fallback.
        """
        # Collapse yellow phases to their parent green for voting purposes
        def normalise(p):
            return PHASE_NS_GREEN if p in (PHASE_NS_GREEN, PHASE_NS_YELLOW) else PHASE_EW_GREEN

        n_d = normalise(v_d)
        n_h = normalise(v_h)
        n_a = normalise(v_a)

        if n_d == n_h == n_a:
            return v_d, "det"   # unanimous
        if n_d == n_h:
            return v_d, "det"
        if n_d == n_a:
            return v_d, "ai"
        if n_h == n_a:
            return v_h, "human"
        # All three disagree — safety fallback to deterministic
        return v_d, "fallback"

    # ─── Explainability Score ─────────────────────────────────────────────────
    def explainability_score(self) -> float:
        """
        ES = weighted average of component ESs, weighted by vote frequency.

        Per §3.8.2: the hybrid's transparency is a blend of its components'
        transparencies, weighted by how often each component controlled the
        outcome.
        """
        es_d = DeterministicController.EXPLAINABILITY_SCORE   # 1.0
        es_h = self.human.explainability_score()
        es_a = self.ai.explainability_score() if self.ai is not None else 0.0

        # Aggregate vote counts across all intersections
        total = {"det": 0, "human": 0, "ai": 0, "fallback": 0}
        for nid_counts in self._vote_counts.values():
            for k, v in nid_counts.items():
                total[k] += v

        grand_total = sum(total.values())
        if grand_total == 0:
            return (es_d + es_h + es_a) / 3.0

        w_d = (total["det"] + total["fallback"]) / grand_total
        w_h = total["human"] / grand_total
        w_a = total["ai"] / grand_total

        return w_d * es_d + w_h * es_h + w_a * es_a

    def reset(self, seed: int = None):
        self.det.reset()
        self.human.reset(seed=seed or self.seed)
        if self.ai is not None:
            self.ai.reset(seed=seed)
        self._vote_counts.clear()

    def __repr__(self):
        has_ai = self.ai is not None
        return (
            f"HybridController(det + human + {'DQN' if has_ai else 'det-fallback'}, "
            f"majority vote)"
        )
