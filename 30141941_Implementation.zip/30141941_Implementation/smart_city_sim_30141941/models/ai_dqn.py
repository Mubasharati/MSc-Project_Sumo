"""
AI Governance Model — §3.6.3

Deep Q-Network (DQN) traffic signal controller trained via reinforcement
learning using stable-baselines3.

Architecture
------------
• State  : queue lengths (N, S, E, W) + current phase + normalised phase timer
           per intersection → 6 features × 16 intersections = 96-dim flat vec
• Action : binary choice per intersection: hold (0) or switch (1)
           — 16 independent decisions per step, approximated by a single
           policy that maps the per-intersection observation to {hold, switch}
• Reward : −(total_queue) at each step  (minimise congestion)
• Training : 500,000 environment steps on random-demand profiles (§3.6.3)

SHAP Explainability
-------------------
After training, SHAP KernelExplainer computes feature contributions for a
sample of decisions.  The Explainability Score (ES) is the mean of the
normalised absolute SHAP values for the top-3 features, averaged across
all decisions in an experimental run.

Usage
-----
    # Train (once):
    from models.ai_dqn import DQNController
    ctrl = DQNController()
    ctrl.train(total_timesteps=500_000)
    ctrl.save("trained_models/dqn_traffic.zip")

    # Load and use:
    ctrl = DQNController.load("trained_models/dqn_traffic.zip")
    results = sim.run_full(controller=ctrl)
"""

from __future__ import annotations

import os
import warnings
from typing import Dict, List, Optional, Tuple

import numpy as np

from config import (
    DQN_LEARNING_RATE, DQN_BATCH_SIZE, DQN_BUFFER_SIZE, DQN_GAMMA,
    DQN_EXPLORATION_FRACTION, DQN_TARGET_UPDATE_INTERVAL,
    DQN_TRAIN_STEPS, TRAINED_MODEL_PATH,
    GRID_ROWS, GRID_COLS,
)
from simulation.grid_sim import (
    PHASE_NS_GREEN, PHASE_NS_YELLOW, PHASE_EW_GREEN, PHASE_EW_YELLOW,
    GREEN_PHASES,
)

NUM_INTERSECTIONS = GRID_ROWS * GRID_COLS
OBS_DIM = 6           # features per intersection
ACTION_DIM = 2        # hold=0 or switch=1 per intersection


import gymnasium as _gym

class _SingleIntersectionEnv(_gym.Env):
    """
    Lightweight Gymnasium-compatible environment for a *single* intersection.
    Used to train one DQN that generalises across all intersections.
    """

    def __init__(self, seed: int = 0):
        self.seed = seed
        self.rng = np.random.default_rng(seed)
        self.obs_dim = OBS_DIM
        self.n_actions = ACTION_DIM
        self._state = None
        self._phase = PHASE_NS_GREEN
        self._phase_timer = 0.0
        self._step_count = 0

        # Gymnasium-style spaces (needed by stable-baselines3)
        import gymnasium as gym
        self.observation_space = gym.spaces.Box(
            low=0.0, high=100.0, shape=(OBS_DIM,), dtype=np.float32
        )
        self.action_space = gym.spaces.Discrete(ACTION_DIM)
        # SB3 compatibility — expose metadata and render_mode
        self.metadata = {}
        self.render_mode = None
        self.spec = None
        self.np_random = None

    def reset(self, seed=None, options=None):
        if seed is not None:
            self.rng = np.random.default_rng(seed)
        demand = self.rng.uniform(0.3, 0.95)
        self._phase = PHASE_NS_GREEN
        self._phase_timer = 0.0
        self._step_count = 0
        self._q = np.zeros(4, dtype=np.float32)
        self._demand = demand
        return self._get_obs(), {}

    def _get_obs(self) -> np.ndarray:
        return np.array([
            self._q[0], self._q[1], self._q[2], self._q[3],
            float(self._phase),
            min(self._phase_timer / 60.0, 1.0),
        ], dtype=np.float32)

    def step(self, action: int) -> Tuple:
        from config import SATURATION_FLOW_PS, MIN_GREEN, YELLOW_DURATION

        sat = SATURATION_FLOW_PS

        # Arrivals (Poisson)
        arr_rate = self._demand * sat * 2
        arrivals = self.rng.poisson(arr_rate / 4, size=4).astype(float)
        self._q += arrivals
        self._q = np.clip(self._q, 0, 100)

        # Apply action
        if self._phase in GREEN_PHASES:
            if action == 1 and self._phase_timer >= MIN_GREEN:
                # Switch to yellow
                self._phase = (self._phase + 1) % 4
                self._phase_timer = 0.0
            else:
                self._phase_timer += 1.0
        else:
            # Yellow: auto-advance
            self._phase_timer += 1.0
            if self._phase_timer >= YELLOW_DURATION:
                self._phase = (self._phase + 1) % 4
                self._phase_timer = 0.0

        # Discharge
        if self._phase == PHASE_NS_GREEN:
            discharged = min(self._q[0] + self._q[1], sat * 2)
            self._q[0] = max(0, self._q[0] - discharged / 2)
            self._q[1] = max(0, self._q[1] - discharged / 2)
        elif self._phase == PHASE_EW_GREEN:
            discharged = min(self._q[2] + self._q[3], sat * 2)
            self._q[2] = max(0, self._q[2] - discharged / 2)
            self._q[3] = max(0, self._q[3] - discharged / 2)

        reward = -float(np.sum(self._q))

        self._step_count += 1
        done = self._step_count >= 3600
        return self._get_obs(), reward, done, False, {}


class DQNController:
    """
    DQN-based traffic signal controller.

    The trained policy is applied independently to each intersection using
    its local 6-feature observation.  SHAP values are collected per decision
    during inference and averaged to compute the Explainability Score.
    """

    def __init__(self, model=None, seed: int = 42):
        self.model = model
        self.seed = seed
        self._shap_values: List[np.ndarray] = []
        self._phase: Dict[str, int] = {}
        self._phase_timer: Dict[str, float] = {}
        self._initialized = False

        # SHAP explainer (built lazily after collecting a reference set)
        self._explainer = None
        self._reference_obs: Optional[np.ndarray] = None

    # ─── Training ─────────────────────────────────────────────────────────────
    @classmethod
    def train(
        cls,
        total_timesteps: int = DQN_TRAIN_STEPS,
        seed: int = 42,
        save_path: str = TRAINED_MODEL_PATH,
        verbose: int = 0,
    ) -> "DQNController":
        """
        Train a DQN on the single-intersection environment for `total_timesteps`
        steps, then save the model.
        """
        from stable_baselines3 import DQN

        env = _SingleIntersectionEnv(seed=seed)

        model = DQN(
            "MlpPolicy",
            env,
            learning_rate=DQN_LEARNING_RATE,
            buffer_size=DQN_BUFFER_SIZE,
            batch_size=DQN_BATCH_SIZE,
            gamma=DQN_GAMMA,
            exploration_fraction=DQN_EXPLORATION_FRACTION,
            target_update_interval=DQN_TARGET_UPDATE_INTERVAL,
            verbose=verbose,
            seed=seed,
        )
        print(f"  Training DQN for {total_timesteps:,} steps …")
        model.learn(total_timesteps=total_timesteps)

        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        model.save(save_path)
        print(f"  DQN saved → {save_path}")

        ctrl = cls(model=model, seed=seed)
        ctrl._build_shap_reference(env)
        return ctrl

    # ─── Loading ──────────────────────────────────────────────────────────────
    @classmethod
    def load(cls, path: str = TRAINED_MODEL_PATH, seed: int = 42) -> "DQNController":
        from stable_baselines3 import DQN
        model = DQN.load(path)
        ctrl = cls(model=model, seed=seed)
        # Re-build reference set from a dummy env
        env = _SingleIntersectionEnv(seed=seed)
        ctrl._build_shap_reference(env)
        return ctrl

    # ─── SHAP reference ───────────────────────────────────────────────────────
    def _build_shap_reference(self, env: _SingleIntersectionEnv, n_samples: int = 200):
        """Collect background reference observations for SHAP KernelExplainer.

        Runs the environment for n_samples steps, collecting observations only
        when queues are non-empty (so reference set reflects realistic states).
        """
        refs = []
        obs, _ = env.reset()
        # Warm-up for 50 steps so queues build up
        for _ in range(50):
            action, _ = self.model.predict(obs, deterministic=True)
            obs, _, done, _, _ = env.step(int(action))
            if done:
                obs, _ = env.reset()
        # Now collect reference observations
        for _ in range(n_samples * 5):
            action, _ = self.model.predict(obs, deterministic=True)
            obs, _, done, _, _ = env.step(int(action))
            if np.sum(obs[:4]) > 0:   # only non-empty queue states
                refs.append(obs.copy())
            if done:
                obs, _ = env.reset()
            if len(refs) >= n_samples:
                break
        if not refs:
            # Fallback: use random realistic observations
            refs = [np.array([5, 3, 2, 4, i % 4, i/60], dtype=np.float32)
                    for i in range(n_samples)]
        self._reference_obs = np.array(refs[:n_samples], dtype=np.float32)

    def _get_explainer(self):
        if self._explainer is None and self._reference_obs is not None:
            import shap, torch

            model_ref = self.model   # capture for closure

            def predict_fn(obs_batch: np.ndarray) -> np.ndarray:
                """Maps observations to predicted action (0=hold, 1=switch)."""
                results = []
                for obs in obs_batch:
                    obs_t = obs.reshape(1, -1).astype(np.float32)
                    with torch.no_grad():
                        q_values = model_ref.q_net(
                            torch.tensor(obs_t)
                        ).numpy()[0]
                    # Numerically stable softmax (subtract max to avoid overflow)
                    q_shifted = q_values - q_values.max()
                    exp_q = np.exp(np.clip(q_shifted, -20, 0))
                    prob_switch = float(exp_q[1] / exp_q.sum())
                    results.append(prob_switch)
                return np.array(results, dtype=np.float64)

            warnings.filterwarnings("ignore")
            ref = np.nan_to_num(self._reference_obs[:20], nan=0.0)
            self._explainer = shap.KernelExplainer(predict_fn, ref)
        return self._explainer

    # ─── Controller interface ─────────────────────────────────────────────────
    def _init(self, obs: dict):
        for nid in obs:
            self._phase[nid] = PHASE_NS_GREEN
            self._phase_timer[nid] = 0.0
        self._initialized = True

    def act(self, obs: dict, sim=None) -> Dict[str, int]:
        """
        Query the DQN for each intersection independently and return phase cmds.
        """
        from config import MIN_GREEN, YELLOW_DURATION

        if self.model is None:
            raise RuntimeError(
                "DQN model not loaded.  Call DQNController.train() or .load() first."
            )

        if not self._initialized:
            self._init(obs)

        self._act_step = getattr(self, "_act_step", 0) + 1
        commands: Dict[str, int] = {}

        for nid, observation in obs.items():
            phase = self._phase[nid]
            timer = self._phase_timer[nid]
            timer += 1.0

            # Yellow: auto-advance
            if phase in (PHASE_NS_YELLOW, PHASE_EW_YELLOW):
                if timer >= YELLOW_DURATION:
                    phase = (phase + 1) % 4
                    timer = 0.0
                self._phase[nid] = phase
                self._phase_timer[nid] = timer
                commands[nid] = phase
                continue

            # Query DQN
            action, _ = self.model.predict(observation, deterministic=True)
            action = int(action)

            # Collect obs for SHAP — delay until step 50 so queues have built up,
            # then sample every 5 steps to spread coverage across the simulation
            if (
                len(self._shap_values) < 500
                and self._act_step > 50
                and self._act_step % 5 == 0
                and np.sum(observation[:4]) > 0   # only collect when queues non-empty
            ):
                self._shap_values.append(observation.copy())

            if action == 1 and timer >= MIN_GREEN:
                # Switch to yellow
                phase = (phase + 1) % 4
                timer = 0.0

            self._phase[nid] = phase
            self._phase_timer[nid] = timer
            commands[nid] = phase

        return commands

    # ─── Explainability Score ─────────────────────────────────────────────────
    def explainability_score(self) -> float:
        """
        ES = mean normalised |SHAP value| of the top-3 features, averaged
        over sampled decisions.  Per §3.8.2.
        """
        if not self._shap_values:
            return 0.0

        explainer = self._get_explainer()
        if explainer is None:
            return 0.0

        sample = np.array(self._shap_values[:30], dtype=np.float32)
        try:
            warnings.filterwarnings("ignore")
            shap_vals = explainer.shap_values(sample)   # (n_samples, n_features)
        except Exception:
            return 0.0

        abs_shap = np.abs(np.array(shap_vals))
        if abs_shap.ndim == 1:
            abs_shap = abs_shap.reshape(1, -1)

        # Normalise each row to sum to 1; skip rows with all-zero shap
        row_sums = abs_shap.sum(axis=1, keepdims=True)
        valid_rows = (row_sums.flatten() > 0)
        if not np.any(valid_rows):
            return 0.5   # conservative fallback: partial explainability

        abs_shap = abs_shap[valid_rows]
        row_sums = row_sums[valid_rows]
        normalised = abs_shap / row_sums

        from config import ES_TOP_FEATURES
        n_features = normalised.shape[1]
        top_k = min(ES_TOP_FEATURES, n_features)
        # Top-k features per decision
        top_k_vals = np.sort(normalised, axis=1)[:, -top_k:]
        return float(np.mean(np.sum(top_k_vals, axis=1)))

    def reset(self, seed: int = None):
        self._phase.clear()
        self._phase_timer.clear()
        self._shap_values.clear()
        self._initialized = False
        if seed is not None:
            self.seed = seed

    def __repr__(self):
        status = "trained" if self.model is not None else "untrained"
        return f"DQNController({status}, seed={self.seed})"
