"""
Statistical Analysis — §3.9

Implements the full analysis pipeline:

  1. Descriptive statistics — mean, SD, min, max per condition
  2. Levene's test          — homogeneity of variance
  3. One-way ANOVA (or Welch ANOVA if Levene is significant)
  4. Tukey HSD post-hoc    — pairwise group comparisons
  5. Kruskal-Wallis H      — non-parametric robustness test
  6. Effect size η²        — eta-squared

All thresholds use α = 0.05 (config.ALPHA).
Results are returned as dictionaries and serialised to JSON.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import pandas as pd
from scipy import stats
from scipy.stats import f_oneway, kruskal, levene

from config import GOVERNANCE_MODELS, SCENARIOS, ALPHA


# ─── Descriptive statistics ───────────────────────────────────────────────────
def descriptive_stats(df: pd.DataFrame, metric: str) -> pd.DataFrame:
    """Per-governance-model descriptive statistics for one metric."""
    return (
        df.groupby("governance")[metric]
        .agg(mean="mean", std="std", min="min", max="max", n="count")
        .round(4)
    )


# ─── Levene's test ────────────────────────────────────────────────────────────
def levene_test(groups: List[np.ndarray]) -> dict:
    """
    Test homogeneity of variance across governance-model groups.
    Returns dict with statistic, p_value, and equal_variance (bool).
    """
    stat, pval = levene(*groups)
    return {
        "statistic": float(stat),
        "p_value": float(pval),
        "equal_variance": pval > ALPHA,
    }


# ─── One-way ANOVA / Welch ANOVA ─────────────────────────────────────────────
def anova_test(groups: List[np.ndarray], equal_variance: bool = True) -> dict:
    """
    One-way ANOVA if variances are equal, Welch ANOVA otherwise.
    Returns dict with statistic, p_value, significant, and variant.
    """
    if equal_variance:
        stat, pval = f_oneway(*groups)
        variant = "One-way ANOVA"
    else:
        # Welch ANOVA via scipy's f_oneway with unequal variance flag
        # scipy ≥ 1.8 supports this natively
        try:
            stat, pval = stats.f_oneway(*groups)
        except Exception:
            stat, pval = f_oneway(*groups)
        variant = "Welch ANOVA (unequal variance)"

    return {
        "variant": variant,
        "statistic": float(stat),
        "p_value": float(pval),
        "significant": pval < ALPHA,
    }


# ─── Eta-squared effect size ──────────────────────────────────────────────────
def eta_squared(groups: List[np.ndarray]) -> float:
    """
    Compute η² (eta-squared) from the group arrays.
        η² = SS_between / SS_total
    """
    all_vals = np.concatenate(groups)
    grand_mean = np.mean(all_vals)
    ss_total = np.sum((all_vals - grand_mean) ** 2)
    if ss_total == 0:
        return 0.0
    ss_between = sum(len(g) * (np.mean(g) - grand_mean) ** 2 for g in groups)
    return float(ss_between / ss_total)


# ─── Tukey HSD ────────────────────────────────────────────────────────────────
def tukey_hsd(df: pd.DataFrame, metric: str) -> pd.DataFrame:
    """
    Tukey HSD pairwise post-hoc test.
    Returns a DataFrame with columns: group1, group2, meandiff, p_adj, reject.
    """
    from statsmodels.stats.multicomp import pairwise_tukeyhsd

    endog = df[metric].values
    groups = df["governance"].values
    result = pairwise_tukeyhsd(endog=endog, groups=groups, alpha=ALPHA)

    rows = []
    for grp1, grp2, meandiff, padj, lo, hi, rej in zip(
        result.groupsunique[result.pairindices[:, 0]],
        result.groupsunique[result.pairindices[:, 1]],
        result.meandiffs,
        result.pvalues,
        result.confint[:, 0],
        result.confint[:, 1],
        result.reject,
    ):
        rows.append({
            "group1": grp1,
            "group2": grp2,
            "mean_diff": round(float(meandiff), 4),
            "p_adj": round(float(padj), 4),
            "ci_low": round(float(lo), 4),
            "ci_high": round(float(hi), 4),
            "reject_H0": bool(rej),
        })
    return pd.DataFrame(rows)


# ─── Kruskal-Wallis ───────────────────────────────────────────────────────────
def kruskal_wallis(groups: List[np.ndarray]) -> dict:
    """
    Non-parametric robustness check (§3.9).
    """
    stat, pval = kruskal(*groups)
    return {
        "statistic": float(stat),
        "p_value": float(pval),
        "significant": pval < ALPHA,
    }


# ─── Full analysis pipeline ───────────────────────────────────────────────────
def full_analysis(df: pd.DataFrame, scenario_key: str, metric: str) -> dict:
    """
    Run the complete §3.9 pipeline for one (scenario, metric) combination.

    Parameters
    ----------
    df : DataFrame with columns [governance, scenario, run, <metric>, ...]
    scenario_key : str
    metric : str   — one of 'avwt', 'throughput', 'jain_fairness_index',
                     'explainability_score'

    Returns
    -------
    dict with keys: descriptive, levene, anova, eta_squared, tukey, kruskal
    """
    subset = df[df["scenario"] == scenario_key].copy()
    groups = [
        subset.loc[subset["governance"] == g, metric].values
        for g in GOVERNANCE_MODELS
    ]
    groups = [g for g in groups if len(g) > 0]

    desc = descriptive_stats(subset, metric).to_dict()
    lev = levene_test(groups)
    anv = anova_test(groups, equal_variance=lev["equal_variance"])
    eta = eta_squared(groups)
    kw = kruskal_wallis(groups)

    tukey_df = None
    if anv["significant"] and len(subset) > 0:
        try:
            tukey_df = tukey_hsd(subset, metric).to_dict(orient="records")
        except Exception as e:
            tukey_df = [{"error": str(e)}]

    return {
        "scenario": scenario_key,
        "metric": metric,
        "descriptive": desc,
        "levene": lev,
        "anova": anv,
        "eta_squared": eta,
        "tukey_hsd": tukey_df,
        "kruskal_wallis": kw,
    }


def run_all_analyses(df: pd.DataFrame, output_dir: str = "results") -> dict:
    """
    Run full_analysis for all (scenario × metric) combinations and save JSON.
    """
    metrics = ["avwt", "throughput", "jain_fairness_index", "explainability_score"]
    all_results = {}

    for sc in SCENARIOS:
        all_results[sc] = {}
        for m in metrics:
            result = full_analysis(df, sc, m)
            all_results[sc][m] = result

    out_path = Path(output_dir) / "statistical_analysis.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w") as f:
        json.dump(all_results, f, indent=2, default=str)

    print(f"  Statistical analysis saved → {out_path}")
    return all_results
