"""
Generate SUMO network files for the 4×4 grid used in the simulation.

Run once:   python network/generate_network.py
Requires:   SUMO netconvert  (apt install sumo)

If SUMO is not installed, the pre-built net.xml shipped in this directory
is used directly by the simulation.
"""

import subprocess
import sys
import os
import xml.etree.ElementTree as ET
from xml.dom import minidom
import math

BASE = os.path.dirname(os.path.abspath(__file__))

# ─── Parameters ───────────────────────────────────────────────────────────────
ROWS = 4
COLS = 4
SPACING = 200          # metres between intersections
LANE_LENGTH = 200      # metres (approach lanes)
SPEED = 13.89          # 50 km/h in m/s
NUM_LANES = 1          # lanes per direction


def _pretty(xml_str: str) -> str:
    reparsed = minidom.parseString(xml_str)
    return reparsed.toprettyxml(indent="  ")


# ─── Nodes (intersections + perimeter sources/sinks) ──────────────────────────
def build_nodes():
    nodes = ET.Element("nodes")
    # Interior grid intersections: id = "n_{row}_{col}"
    for r in range(ROWS):
        for c in range(COLS):
            ET.SubElement(nodes, "node", {
                "id": f"n_{r}_{c}",
                "x": str(c * SPACING),
                "y": str(r * SPACING),
                "type": "traffic_light",
            })
    # Perimeter source/sink nodes  (just outside the grid)
    # North (row 3, col 0-3)
    for c in range(COLS):
        ET.SubElement(nodes, "node", {
            "id": f"src_N_{c}",
            "x": str(c * SPACING),
            "y": str(ROWS * SPACING),
            "type": "priority",
        })
    # South (row 0, col 0-3)
    for c in range(COLS):
        ET.SubElement(nodes, "node", {
            "id": f"src_S_{c}",
            "x": str(c * SPACING),
            "y": str(-SPACING),
            "type": "priority",
        })
    # West (col 0, row 0-3)
    for r in range(ROWS):
        ET.SubElement(nodes, "node", {
            "id": f"src_W_{r}",
            "x": str(-SPACING),
            "y": str(r * SPACING),
            "type": "priority",
        })
    # East (col 3, row 0-3)
    for r in range(ROWS):
        ET.SubElement(nodes, "node", {
            "id": f"src_E_{r}",
            "x": str(COLS * SPACING),
            "y": str(r * SPACING),
            "type": "priority",
        })
    return nodes


# ─── Edges ────────────────────────────────────────────────────────────────────
def build_edges():
    edges = ET.Element("edges")
    speed = SPEED
    nl = NUM_LANES

    def add_edge(eid, frm, to):
        ET.SubElement(edges, "edge", {
            "id": eid, "from": frm, "to": to,
            "numLanes": str(nl), "speed": str(speed),
        })

    # Horizontal edges (E-W within grid)
    for r in range(ROWS):
        for c in range(COLS - 1):
            add_edge(f"e_{r}_{c}_EW", f"n_{r}_{c}", f"n_{r}_{c+1}")
            add_edge(f"e_{r}_{c+1}_WE", f"n_{r}_{c+1}", f"n_{r}_{c}")

    # Vertical edges (N-S within grid)
    for r in range(ROWS - 1):
        for c in range(COLS):
            add_edge(f"e_{r}_{c}_NS", f"n_{r}_{c}", f"n_{r+1}_{c}")
            add_edge(f"e_{r+1}_{c}_SN", f"n_{r+1}_{c}", f"n_{r}_{c}")

    # Perimeter source→grid and grid→sink edges
    for c in range(COLS):
        add_edge(f"src_N_{c}_in",  f"src_N_{c}",  f"n_{ROWS-1}_{c}")
        add_edge(f"src_N_{c}_out", f"n_{ROWS-1}_{c}", f"src_N_{c}")
        add_edge(f"src_S_{c}_in",  f"src_S_{c}",  f"n_0_{c}")
        add_edge(f"src_S_{c}_out", f"n_0_{c}",    f"src_S_{c}")
    for r in range(ROWS):
        add_edge(f"src_W_{r}_in",  f"src_W_{r}",  f"n_{r}_0")
        add_edge(f"src_W_{r}_out", f"n_{r}_0",    f"src_W_{r}")
        add_edge(f"src_E_{r}_in",  f"src_E_{r}",  f"n_{r}_{COLS-1}")
        add_edge(f"src_E_{r}_out", f"n_{r}_{COLS-1}", f"src_E_{r}")

    return edges


def write_xml(root, path):
    xml_bytes = ET.tostring(root, encoding="unicode")
    with open(path, "w") as f:
        f.write('<?xml version="1.0" encoding="UTF-8"?>\n')
        f.write(xml_bytes)
    print(f"  Written: {path}")


def main():
    nod_path = os.path.join(BASE, "grid.nod.xml")
    edg_path = os.path.join(BASE, "grid.edg.xml")
    net_path = os.path.join(BASE, "grid.net.xml")

    write_xml(build_nodes(), nod_path)
    write_xml(build_edges(), edg_path)

    try:
        cmd = [
            "netconvert",
            "--node-files", nod_path,
            "--edge-files", edg_path,
            "--output-file", net_path,
            "--tls.default-type", "static",
            "--tls.cycle.time", "90",
        ]
        subprocess.run(cmd, check=True, capture_output=True)
        print(f"  SUMO network built: {net_path}")
    except FileNotFoundError:
        print("  netconvert not found — SUMO not installed.")
        print("  The pure-Python simulator will be used instead.")
    except subprocess.CalledProcessError as e:
        print(f"  netconvert failed: {e.stderr.decode()}")


if __name__ == "__main__":
    main()
