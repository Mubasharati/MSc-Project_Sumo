"""
Central configuration for the Smart City Traffic Governance Simulation.

Dissertation: Comparative Analysis of Human, AI, and Deterministic Governance
Decisions for Smart City Management — Mubasharati Jannat (30141941)
"""

# ─── Network ──────────────────────────────────────────────────────────────────
GRID_ROWS = 4
GRID_COLS = 4
NUM_INTERSECTIONS = GRID_ROWS * GRID_COLS          # 16

LANE_LENGTH_M = 200        # metres between intersections
SPEED_LIMIT_MPS = 13.89    # 50 km/h in m/s

# ─── Traffic signal phases ─────────────────────────────────────────────────────
# Phase 0: North-South green
# Phase 1: North-South yellow (all-red clearance)
# Phase 2: East-West green
# Phase 3: East-West yellow (all-red clearance)
YELLOW_DURATION = 3        # seconds per yellow phase
MIN_GREEN = 10             # minimum green duration (human conservatism)
LOST_TIME_PER_PHASE = 3    # Webster lost time per phase (seconds)

# ─── Vehicle / flow parameters ─────────────────────────────────────────────────
SATURATION_FLOW = 1800     # vehicles/hour per lane
SATURATION_FLOW_PS = SATURATION_FLOW / 3600  # vehicles/second

HEADWAY_S = 2.0            # minimum headway at saturation (seconds)
MAX_VEHICLES = 2000        # cap on simultaneously simulated vehicles

# ─── Scenarios ────────────────────────────────────────────────────────────────
SIMULATION_DURATION = 3600  # 1 hour in seconds
NUM_RUNS = 30               # replications per scenario-condition pair

SCENARIOS = {
    "peak": {
        "label": "Scenario A — Peak Demand",
        "demand_factor": 0.90,        # 90 % of theoretical capacity
        "disruption": False,
    },
    "offpeak": {
        "label": "Scenario B — Off-Peak Demand",
        "demand_factor": 0.40,        # 40 % of capacity
        "disruption": False,
    },
    "disruption": {
        "label": "Scenario C — Disruption",
        "demand_factor": 0.65,        # average; split changes at t=1800 s
        "disruption": True,
        "disruption_time": 1800,      # midpoint of simulation
        "disruption_demand": 0.90,    # elevated demand on disrupted half
    },
}

GOVERNANCE_MODELS = ["deterministic", "human", "ai", "hybrid"]

# ─── Human governance ──────────────────────────────────────────────────────────
HUMAN_REACTION_TIME = 6    # seconds
HUMAN_ERROR_RATE = 0.05    # 5 % random errors

# ─── AI / DQN parameters ──────────────────────────────────────────────────────
DQN_TRAIN_STEPS   = 500_000
DQN_LEARNING_RATE = 1e-3
DQN_BATCH_SIZE    = 64
DQN_BUFFER_SIZE   = 50_000
DQN_GAMMA         = 0.95
DQN_EXPLORATION_FRACTION = 0.30
DQN_TARGET_UPDATE_INTERVAL = 500
DQN_N_ENVS       = 1
TRAINED_MODEL_PATH = "trained_models/dqn_traffic.zip"

# ─── Metrics ──────────────────────────────────────────────────────────────────
# Explainability Score thresholds
ES_TOP_FEATURES = 3        # SHAP top-N features for normalised score

# ─── Statistical analysis ─────────────────────────────────────────────────────
ALPHA = 0.05               # significance level

# ─── Random seed base ─────────────────────────────────────────────────────────
SEED_BASE = 42             # run i uses seed SEED_BASE + i

# ─── SUMO settings (used only when SUMO is installed) ─────────────────────────
SUMO_BINARY = "sumo"
SUMO_GUI_BINARY = "sumo-gui"
SUMO_CFG_PATH = "network/grid.sumocfg"
SUMO_STEP_LENGTH = 1.0     # seconds per simulation step
